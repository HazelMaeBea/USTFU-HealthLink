"use client"

import { useState } from "react"
import Image from "next/image"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

export default function ApplicationForm() {
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    gender: "",
    collegeAffiliation: "",
    contactNo: "",
    hospital: "",
    natureOfIllness: "",
    physician: "",
    procedures: "",
    termAY: "",
    termYear: "",
    teachingLoad: "",
    status: "",
    dateHired: "",
    dateRetired: "",
    healthBenefits: "",
  })

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Out-Patient%20Sample.jpg-KRDRipyVKZaKXTOGHCNgAyeKSltRs6.jpeg"
            alt="UST Logo"
            width={100}
            height={100}
            className="opacity-0"
          />
          <Image src="/placeholder.svg?height=100&width=100" alt="UST Logo" width={100} height={100} />
        </div>
        <div className="text-center flex-1">
          <h1 className="text-xl font-bold uppercase">University of Santo Tomas</h1>
          <h2 className="text-xl font-bold uppercase">University of Santo Tomas Faculty Union</h2>
        </div>
        <div>
          <Image src="/placeholder.svg?height=100&width=100" alt="USTFU Logo" width={100} height={100} />
        </div>
      </div>

      <div className="text-center mb-6">
        <h2 className="text-lg font-bold uppercase">Hospitalization and Medical Benefits Fund</h2>
        <h3 className="text-lg font-bold">Application Form: Out-Patient</h3>
      </div>

      <div className="border border-black p-4 mb-4">
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <div className="flex items-center mb-2">
              <Label className="min-w-20">Name:</Label>
              <div className="flex-1 border-b border-black"></div>
            </div>
            <div className="flex items-center mb-2">
              <Label className="min-w-20">Age:</Label>
              <div className="flex-1 border-b border-black"></div>
              <Label className="min-w-20 ml-4">Gender:</Label>
              <div className="flex-1 border-b border-black"></div>
            </div>
            <div className="flex items-center mb-2">
              <Label className="min-w-20">College Affiliation:</Label>
              <div className="flex-1 border-b border-black"></div>
            </div>
            <div className="flex items-center mb-2">
              <Label className="min-w-20">Contact No.:</Label>
              <div className="flex-1 border-b border-black"></div>
            </div>
            <div className="flex items-center mb-2">
              <Label className="min-w-20">Hospital:</Label>
              <div className="flex-1 border-b border-black"></div>
            </div>
            <div className="flex items-center mb-2">
              <Label className="min-w-20">Nature of Illness:</Label>
              <div className="flex-1 border-b border-black"></div>
            </div>
            <div className="flex items-center mb-2">
              <Label className="min-w-20">Physician:</Label>
              <div className="flex-1 border-b border-black"></div>
            </div>
            <div className="flex items-center mb-2">
              <Label className="min-w-20">Procedure/s:</Label>
              <div className="flex-1 border-b border-black"></div>
            </div>
          </div>

          <div>
            <div className="flex items-center mb-2">
              <Label className="min-w-20">Term AY 20</Label>
              <div className="w-16 border-b border-black"></div>
              <Label className="mx-2">-20</Label>
              <div className="w-16 border-b border-black"></div>
            </div>
            <div className="flex items-center mb-2">
              <Label className="min-w-20">Present Teaching Load:</Label>
              <div className="flex-1 border-b border-black"></div>
              <Label className="ml-1">units</Label>
            </div>
            <div className="mb-2">
              <Label className="block mb-1">Status:</Label>
              <div className="ml-4">
                <div className="flex items-center mb-1">
                  <Checkbox id="tenured" className="mr-2 rounded-full" />
                  <Label htmlFor="tenured">Tenured</Label>
                </div>
                <div className="flex items-center mb-1">
                  <Checkbox id="tenure-track" className="mr-2 rounded-full" />
                  <Label htmlFor="tenure-track">Tenure-Track (Date Hired:</Label>
                  <div className="w-32 border-b border-black mx-1"></div>
                  <Label>)</Label>
                </div>
                <div className="flex items-center mb-1">
                  <Checkbox id="lecturer" className="mr-2 rounded-full" />
                  <Label htmlFor="lecturer">Lecturer before 2001</Label>
                </div>
                <div className="flex items-center mb-1">
                  <Checkbox id="extendee" className="mr-2 rounded-full" />
                  <Label htmlFor="extendee">Extendee</Label>
                </div>
                <div className="flex items-center mb-1">
                  <Checkbox id="retiree" className="mr-2 rounded-full" />
                  <Label htmlFor="retiree">Retiree (Date Retired:</Label>
                  <div className="w-32 border-b border-black mx-1"></div>
                  <Label>)</Label>
                </div>
              </div>
            </div>
            <div className="mb-2">
              <Label className="block mb-1">Health Benefits:</Label>
              <div className="ml-4">
                <div className="flex items-center mb-1">
                  <Checkbox id="hmo" className="mr-2 rounded-full" />
                  <Label htmlFor="hmo">HMO:</Label>
                  <div className="w-32 border-b border-black ml-2"></div>
                </div>
                <div className="flex items-center mb-1">
                  <Checkbox id="pcso" className="mr-2 rounded-full" />
                  <Label htmlFor="pcso">PCSO</Label>
                </div>
                <div className="flex items-center mb-1">
                  <Checkbox id="senior" className="mr-2 rounded-full" />
                  <Label htmlFor="senior">Senior Citizen</Label>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-4">
          <p className="text-sm">
            I hereby certify that all information in this application is true and correct and any misrepresentation of
            facts shall be sufficient cause for denial of this benefit. For any amount in excess of my maximum medical &
            hospitalization benefit, I am personally liable to pay directly to UST Hospital.
          </p>
        </div>

        <div className="flex justify-end">
          <div className="w-64 border-t border-black text-center">
            <p className="text-sm">Applicant's Signature / Date</p>
          </div>
        </div>
      </div>

      <div className="text-center text-sm mb-2 border-b border-black pb-1">
        Please do not write anything below this line. USTFU use only.
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="border border-black p-2">
          <h3 className="font-bold">To UST HOSPITAL:</h3>
          <p className="text-sm mb-2">
            This certifies that the above named faculty is entitled to the following benefit on his/her total charges
            (procedure, supplies, drugs and reader's fee) but not to exceed his/her remaining benefit subject to final
            verification:
          </p>

          <div className="flex items-center mb-1">
            <Checkbox id="fifty" className="mr-2 rounded-full" />
            <Label htmlFor="fifty" className="text-sm">
              50% of net hospital bill but not to exceed (₱
            </Label>
            <div className="flex-1 border-b border-black mx-1"></div>
            <Label className="text-sm">)</Label>
          </div>
          <div className="flex items-center mb-1">
            <Checkbox id="hundred" className="mr-2 rounded-full" />
            <Label htmlFor="hundred" className="text-sm">
              100% of net hospital bill
            </Label>
          </div>

          <div className="text-right text-xs italic mb-1">Remaining Benefit</div>

          <div className="text-center font-bold mt-4">EMERITO C. GONZALES</div>
          <div className="text-center text-xs">USTFU President or Authorized Representative (Blue ink)</div>
        </div>

        <div className="border border-black p-2">
          <h3 className="font-bold">To Department/ Unit Concerned:</h3>
          <div className="p-2">
            <p className="text-sm mb-2">
              Please allow 50% or 100% discount on the requested procedure/s on the indicated remaining benefit.
            </p>
            <div className="flex items-center mb-1">
              <Label className="text-sm">VALID UNTIL</Label>
              <div className="flex-1 border-b border-black mx-1"></div>
            </div>
            <div className="flex items-center mb-1">
              <Label className="text-sm">BY:</Label>
              <div className="flex-1 border-b border-black mx-1"></div>
            </div>
            <div className="text-center text-xs">USTFU Credit and Collection</div>
          </div>
        </div>
      </div>

      <div className="border border-black p-2 mb-4">
        <h3 className="font-bold">To UST-USTFU HOSPITALIZATION FUND:</h3>

        <div className="grid grid-cols-3 gap-4">
          <div className="col-span-1">
            <div className="flex items-start mb-2">
              <Checkbox id="pay-hospital" className="mr-2 mt-1" />
              <Label htmlFor="pay-hospital" className="text-sm">
                Pay UST HOSPITAL the amount of:
              </Label>
            </div>
            <div className="flex items-start mb-2">
              <Checkbox id="refund-faculty" className="mr-2 mt-1" />
              <Label htmlFor="refund-faculty" className="text-sm">
                Refund the FACULTY the amount of:
              </Label>
            </div>
            <div className="border-2 border-black p-2 mt-4">
              <div className="flex items-start mb-2">
                <Checkbox id="not-covered" className="mr-2 mt-1" />
                <Label htmlFor="not-covered" className="text-sm">
                  Amount NOT covered by benefits of the FACULTY and will NOT be settled by USTFU. The faculty shall pay
                  this amount directly to UST Hospital.
                </Label>
              </div>
            </div>
          </div>

          <div className="col-span-1">
            <div className="flex items-center mb-4">
              <Label className="text-sm">₱:</Label>
              <div className="flex-1 border-b border-black mx-1"></div>
            </div>
            <div className="flex items-center mb-4">
              <Label className="text-sm">₱:</Label>
              <div className="flex-1 border-b border-black mx-1"></div>
            </div>
            <div className="flex items-center mb-4 mt-8">
              <Label className="text-sm">₱:</Label>
              <div className="flex-1 border-b border-black mx-1"></div>
            </div>
          </div>

          <div className="col-span-1">
            <div className="mb-2">
              <Checkbox id="pay-doctors" className="mr-2" />
              <Label htmlFor="pay-doctors" className="text-sm">
                Pay the following DOCTORS the amount of:
              </Label>
            </div>
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="border border-black text-sm p-1">Name</th>
                  <th className="border border-black text-sm p-1">Amount</th>
                </tr>
              </thead>
              <tbody>
                {[...Array(6)].map((_, i) => (
                  <tr key={i}>
                    <td className="border border-black p-1 h-6"></td>
                    <td className="border border-black p-1 h-6"></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex items-center mt-4">
          <div className="mr-auto">
            <div className="font-bold">CTRL No.: 2024-04573</div>
          </div>
          <div>
            <Label className="text-sm">By:</Label>
            <div className="w-64 border-b border-black mx-1"></div>
            <div className="text-center text-xs">OIC for Hospitalization and Medical Benefits</div>
          </div>
        </div>
      </div>

      <div className="flex justify-between text-xs">
        <div>USTFU Med -2 Form</div>
        <div>Revised: 03/16/2020 ONLINE FORM</div>
      </div>
    </div>
  )
}

