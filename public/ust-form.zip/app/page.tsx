import FormGenerator from "@/components/form-generator"

export default function Home() {
  return (
    <main className="min-h-screen p-6 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold mb-6 text-center">USTFU Medical Benefits Form Generator</h1>
        <FormGenerator />
      </div>
    </main>
  )
}

