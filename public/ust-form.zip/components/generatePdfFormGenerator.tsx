"use client"

import { useState } from "react"
import type { FormData } from "@/types"
import OutPatientForm from "./forms/outPatientForm"
import InPatientForm from "./forms/inPatientForm"
import AdmissionForm from "./forms/admissionForm"
import EyeglassesForm from "./forms/eyeglassesForm"
import { generatePDF } from "@/lib/pdf-generator"

const formStyles = {
  container: {
    fontFamily: "Arial, sans-serif",
    maxWidth: "800px",
    margin: "0 auto",
    padding: "20px",
  },
  header: {
    textAlign: "center" as const,
    marginBottom: "20px",
  },
  title: {
    fontSize: "24px",
    fontWeight: "bold",
  },
  formSelector: {
    marginBottom: "20px",
  },
  select: {
    width: "100%",
    padding: "10px",
    fontSize: "16px",
  },
  generateButton: {
    backgroundColor: "#4CAF50",
    border: "none",
    color: "white",
    padding: "15px 32px",
    textAlign: "center" as const,
    textDecoration: "none",
    display: "inline-block",
    fontSize: "16px",
    margin: "4px 2px",
    cursor: "pointer",
  },
}

export default function GeneratePdfFormGenerator() {
  const [activeForm, setActiveForm] = useState<string>("outpatient")
  const [formData, setFormData] = useState<Partial<FormData>>({
    lastname: "",
    firstname: "",
    middlename: "",
    age: 0,
    gender: "Male",
    contact: 0,
    college: "",
    formType: "hospital",
    origFormType: "Out-Patient",
    hospitalStatus: "Out-Patient",
  })

  const handleFormChange = (data: Partial<FormData>) => {
    setFormData({ ...formData, ...data })
  }

  const handleGeneratePDF = () => {
    const formElement = document.getElementById(`${activeForm}-form`)
    if (formElement) {
      generatePDF(formElement, `${activeForm}-form-${formData.lastname}-${formData.firstname}`)
    }
  }

  return (
    <div style={formStyles.container}>
      <div style={formStyles.header}>
        <h1 style={formStyles.title}>USTFU Medical Benefits Form Generator</h1>
      </div>
      <div style={formStyles.formSelector}>
        <select style={formStyles.select} value={activeForm} onChange={(e) => setActiveForm(e.target.value)}>
          <option value="outpatient">Out-Patient</option>
          <option value="inpatient">In-Patient</option>
          <option value="admission">Admission</option>
          <option value="eyeglasses">Eyeglasses</option>
        </select>
      </div>
      <div id={`${activeForm}-form`}>
        {activeForm === "outpatient" && <OutPatientForm formData={formData} onChange={handleFormChange} />}
        {activeForm === "inpatient" && <InPatientForm formData={formData} onChange={handleFormChange} />}
        {activeForm === "admission" && <AdmissionForm formData={formData} onChange={handleFormChange} />}
        {activeForm === "eyeglasses" && <EyeglassesForm formData={formData} onChange={handleFormChange} />}
      </div>
      <button style={formStyles.generateButton} onClick={handleGeneratePDF}>
        Generate PDF
      </button>
    </div>
  )
}

