"use client"

import { useState } from "react"
import type { FormData } from "@/types"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import OutPatientForm from "./forms/out-patient-form"
import InPatientForm from "./forms/in-patient-form"
import AdmissionForm from "./forms/admission-form"
import EyeglassesForm from "./forms/eyeglasses-form"
import { generatePDF } from "@/lib/pdf-generator"

export default function FormGenerator() {
  const [activeForm, setActiveForm] = useState<string>("outpatient")
  const [formData, setFormData] = useState<Partial<FormData>>({
    lastname: "",
    firstname: "",
    middlename: "",
    age: 0,
    gender: "Male",
    contact: 0,
    college: "",
    formType: "hospital",
    origFormType: "Out-Patient",
    hospitalStatus: "Out-Patient",
  })

  const handleFormChange = (data: Partial<FormData>) => {
    setFormData({ ...formData, ...data })
  }

  const handleGeneratePDF = () => {
    const formElement = document.getElementById(`${activeForm}-form`)
    if (formElement) {
      generatePDF(formElement, `${activeForm}-form-${formData.lastname}-${formData.firstname}`)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>USTFU Medical Benefits Form Generator</CardTitle>
          <CardDescription>Fill out the form details and generate a PDF for submission</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="outpatient" onValueChange={setActiveForm}>
            <TabsList className="grid grid-cols-4 mb-6">
              <TabsTrigger value="outpatient">Out-Patient</TabsTrigger>
              <TabsTrigger value="inpatient">In-Patient</TabsTrigger>
              <TabsTrigger value="admission">Admission</TabsTrigger>
              <TabsTrigger value="eyeglasses">Eyeglasses</TabsTrigger>
            </TabsList>

            <TabsContent value="outpatient" id="outpatient-form">
              <OutPatientForm formData={formData} onChange={handleFormChange} />
            </TabsContent>

            <TabsContent value="inpatient" id="inpatient-form">
              <InPatientForm formData={formData} onChange={handleFormChange} />
            </TabsContent>

            <TabsContent value="admission" id="admission-form">
              <AdmissionForm formData={formData} onChange={handleFormChange} />
            </TabsContent>

            <TabsContent value="eyeglasses" id="eyeglasses-form">
              <EyeglassesForm formData={formData} onChange={handleFormChange} />
            </TabsContent>
          </Tabs>

          <div className="flex justify-end mt-6">
            <Button onClick={handleGeneratePDF} className="bg-blue-600 hover:bg-blue-700">
              Generate PDF
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

