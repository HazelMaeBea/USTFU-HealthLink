"use client"

import { useState, useEffect } from "react"
import type { FormData, EyeglassesFormData } from "@/types"

const formStyles = {
  container: {
    fontFamily: "Arial, sans-serif",
  },
  header: {
    textAlign: "center" as const,
    marginBottom: "20px",
  },
  title: {
    fontSize: "20px",
    fontWeight: "bold",
  },
  subtitle: {
    fontSize: "16px",
    fontStyle: "italic",
  },
  formGroup: {
    marginBottom: "15px",
  },
  label: {
    display: "block",
    marginBottom: "5px",
    fontWeight: "bold",
  },
  input: {
    width: "100%",
    padding: "5px",
    fontSize: "14px",
  },
  signatureSection: {
    marginTop: "20px",
    borderTop: "1px solid #ccc",
    paddingTop: "10px",
  },
}

interface EyeglassesFormProps {
  formData: Partial<FormData>
  onChange: (data: Partial<FormData>) => void
}

export default function EyeglassesForm({ formData, onChange }: EyeglassesFormProps) {
  const [localData, setLocalData] = useState<Partial<EyeglassesFormData>>({
    ...formData,
    formType: "eyeglasses",
  } as Partial<EyeglassesFormData>)

  useEffect(() => {
    setLocalData({ ...formData, formType: "eyeglasses" } as Partial<EyeglassesFormData>)
  }, [formData])

  const handleChange = (field: string, value: any) => {
    const updatedData = { ...localData, [field]: value }
    setLocalData(updatedData)
    onChange(updatedData)
  }

  return (
    <div style={formStyles.container}>
      <div style={formStyles.header}>
        <h2 style={formStyles.title}>HOSPITALIZATION AND MEDICAL BENEFITS FUND</h2>
        <h3 style={formStyles.subtitle}>Eyeglasses Benefit Availment Form</h3>
        <p>(Note: For Tenured Faculty Members Only)</p>
      </div>

      <div style={formStyles.formGroup}>
        <label style={formStyles.label}>Term, AY:</label>
        <input
          type="text"
          style={formStyles.input}
          value={`${localData.term || ""} - ${localData.year || ""}`}
          onChange={(e) => {
            const [term, year] = e.target.value.split(" - ")
            handleChange("term", term)
            handleChange("year", year)
          }}
        />
      </div>

      <div style={formStyles.formGroup}>
        <label style={formStyles.label}>Name:</label>
        <input
          type="text"
          style={formStyles.input}
          value={`${localData.lastname || ""}, ${localData.firstname || ""} ${localData.middlename || ""}`}
          onChange={(e) => {
            const [lastname, firstname, middlename] = e.target.value.split(", ")
            handleChange("lastname", lastname)
            handleChange("firstname", firstname)
            handleChange("middlename", middlename)
          }}
        />
      </div>

      <div style={formStyles.formGroup}>
        <label style={formStyles.label}>Age:</label>
        <input
          type="number"
          style={formStyles.input}
          value={localData.age || ""}
          onChange={(e) => handleChange("age", Number.parseInt(e.target.value))}
        />
      </div>

      <div style={formStyles.formGroup}>
        <label style={formStyles.label}>Sex:</label>
        <input
          type="text"
          style={formStyles.input}
          value={localData.gender || ""}
          onChange={(e) => handleChange("gender", e.target.value)}
        />
      </div>

      <div style={formStyles.formGroup}>
        <label style={formStyles.label}>Affiliation:</label>
        <input
          type="text"
          style={formStyles.input}
          value={localData.college || ""}
          onChange={(e) => handleChange("college", e.target.value)}
        />
      </div>

      <div style={formStyles.formGroup}>
        <label style={formStyles.label}>Initial Employment:</label>
        <input
          type="date"
          style={formStyles.input}
          value={localData.initialEmployment || ""}
          onChange={(e) => handleChange("initialEmployment", e.target.value)}
        />
      </div>

      <div style={formStyles.formGroup}>
        <label style={formStyles.label}>Current Teaching Load:</label>
        <input
          type="text"
          style={formStyles.input}
          value={localData.load || ""}
          onChange={(e) => handleChange("load", e.target.value)}
        />
      </div>

      <div style={formStyles.formGroup}>
        <label style={formStyles.label}>Contact No.:</label>
        <input
          type="tel"
          style={formStyles.input}
          value={localData.contact || ""}
          onChange={(e) => handleChange("contact", e.target.value)}
        />
      </div>

      <div style={formStyles.formGroup}>
        <label style={formStyles.label}>Official Receipt Details:</label>
        <div>
          <label>Issued By:</label>
          <input
            type="text"
            style={formStyles.input}
            value={localData.issuedBy || ""}
            onChange={(e) => handleChange("issuedBy", e.target.value)}
          />
        </div>
        <div>
          <label>Number:</label>
          <input
            type="text"
            style={formStyles.input}
            value={localData.ORNumber || ""}
            onChange={(e) => handleChange("ORNumber", e.target.value)}
          />
        </div>
        <div>
          <label>Amount Paid:</label>
          <input
            type="number"
            style={formStyles.input}
            value={localData.amountPaid || ""}
            onChange={(e) => handleChange("amountPaid", Number.parseFloat(e.target.value))}
          />
        </div>
      </div>

      <div>
        <p>
          I hereby certify that all information in this application are true and correct and any misrepresentation of
          fact/s shall be sufficient cause for denial of this benefit.
        </p>
      </div>

      <div style={formStyles.signatureSection}>
        <div>
          <label>Applicant's Signature over Printed Name:</label>
          <input type="text" style={formStyles.input} />
        </div>
        <div>
          <label>Date:</label>
          <input type="date" style={formStyles.input} />
        </div>
      </div>

      <div style={formStyles.signatureSection}>
        <h4>USTFU Section</h4>
        <p>
          The faculty is entitled to a reimbursement of ₱
          <input
            type="number"
            style={{ ...formStyles.input, width: "100px" }}
            value={localData.reimbursementAmount || ""}
            onChange={(e) => handleChange("reimbursementAmount", Number.parseFloat(e.target.value))}
          />
          for his/her eyeglasses benefit.
        </p>
        <div>
          <label>OIC for Hospitalization and Medical Benefits:</label>
          <input type="text" style={formStyles.input} />
        </div>
      </div>

      <div>
        <p>
          <strong>NOTE:</strong>
        </p>
        <ol>
          <li>This form should be accomplished fully and personally by the faculty member.</li>
          <li>
            Submit this form to USTFU together with the OPHTHALMOLOGIST'S FINDINGS/VISIONAL RESULTS and OFFICIAL RECEIPT
            OF THE EYEGLASSES.
          </li>
        </ol>
      </div>
    </div>
  )
}

