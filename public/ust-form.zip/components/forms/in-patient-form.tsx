"use client"

import { useState } from "react"
import type { FormData, HospitalFormData } from "@/types"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { FileUploader } from "../file-uploader"

interface InPatientFormProps {
  formData: Partial<FormData>
  onChange: (data: Partial<FormData>) => void
}

export default function InPatientForm({ formData, onChange }: InPatientFormProps) {
  const [localData, setLocalData] = useState<Partial<HospitalFormData>>(\
    { ...form  {
  const [localData, setLocalData] = useState<Partial<HospitalFormData>>(
    { ...formData, origFormType: "In-Patient", hospitalStatus: "In-Patient" } as Partial<HospitalFormData>
  )

  useEffect(() => {
    // Update local state when parent formData changes
    setLocalData({ ...formData, origFormType: "In-Patient", hospitalStatus: "In-Patient" } as Partial<HospitalFormData>)
  }, [formData])

  const handleChange = (field: string, value: any) => {
    const updatedData = { ...localData, [field]: value }
    setLocalData(updatedData)
    onChange(updatedData)
  }

  const handleFileChange = (field: string, fileData: { url: string; filename: string }) => {
    handleChange(field, fileData)
  }

  return (
    <div className="print-container">
      <div className="form-container border border-black p-4 max-w-4xl mx-auto bg-white">
        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div className="w-24 h-24">
            <img src="/placeholder.svg?height=100&width=100" alt="UST Logo" className="w-full h-full object-contain" />
          </div>
          <div className="text-center flex-1">
            <h1 className="text-xl font-bold uppercase">University of Santo Tomas</h1>
            <h2 className="text-xl font-bold uppercase">University of Santo Tomas Faculty Union</h2>
            <h3 className="text-lg font-bold mt-2">HOSPITALIZATION AND MEDICAL BENEFITS FUND</h3>
            <h4 className="text-lg font-bold">Application Form: In-Patient</h4>
          </div>
          <div className="w-24 h-24">
            <img
              src="/placeholder.svg?height=100&width=100"
              alt="USTFU Logo"
              className="w-full h-full object-contain"
            />
          </div>
        </div>

        {/* Form Type Selection */}
        <div className="border border-black p-2 mb-4">
          <RadioGroup
            value={localData.hospitalStatus}
            onValueChange={(value: "In-Patient" | "Out-Patient" | "ER Consultation") =>
              handleChange("hospitalStatus", value)
            }
            className="flex space-x-4"
          >
            <div className="flex items-center space-x-1">
              <RadioGroupItem value="In-Patient" id="in-patient" />
              <Label htmlFor="in-patient">For Confinement</Label>
            </div>
            <div className="flex items-center space-x-1">
              <RadioGroupItem value="Out-Patient" id="out-patient" />
              <Label htmlFor="out-patient">Done as Out-Patient</Label>
            </div>
            <div className="flex items-center space-x-1">
              <RadioGroupItem value="ER Consultation" id="er-consultation" />
              <Label htmlFor="er-consultation">ER Consultation</Label>
            </div>
          </RadioGroup>
        </div>

        {/* Form Content */}
        <div className="border border-black p-4 mb-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <div className="flex items-center">
                <Label className="w-24">Name:</Label>
                <div className="flex-1 space-x-2">
                  <Input
                    placeholder="Last Name"
                    value={localData.lastname || ""}
                    onChange={(e) => handleChange("lastname", e.target.value)}
                    className="inline-block w-1/3"
                  />
                  <Input
                    placeholder="First Name"
                    value={localData.firstname || ""}
                    onChange={(e) => handleChange("firstname", e.target.value)}
                    className="inline-block w-1/3"
                  />
                  <Input
                    placeholder="Middle Name"
                    value={localData.middlename || ""}
                    onChange={(e) => handleChange("middlename", e.target.value)}
                    className="inline-block w-1/4"
                  />
                </div>
              </div>

              <div className="flex items-center">
                <Label className="w-24">Age:</Label>
                <Input
                  type="number"
                  value={localData.age || ""}
                  onChange={(e) => handleChange("age", Number.parseInt(e.target.value))}
                  className="w-20"
                />
                <Label className="ml-4 w-24">Gender:</Label>
                <RadioGroup
                  value={localData.gender}
                  onValueChange={(value) => handleChange("gender", value)}
                  className="flex space-x-4"
                >
                  <div className="flex items-center space-x-1">
                    <RadioGroupItem value="Male" id="male" />
                    <Label htmlFor="male">Male</Label>
                  </div>
                  <div className="flex items-center space-x-1">
                    <RadioGroupItem value="Female" id="female" />
                    <Label htmlFor="female">Female</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="flex items-center">
                <Label className="w-24">College:</Label>
                <Input
                  value={localData.college || ""}
                  onChange={(e) => handleChange("college", e.target.value)}
                  className="flex-1"
                />
              </div>

              <div className="flex items-center">
                <Label className="w-24">Contact No.:</Label>
                <Input
                  type="number"
                  value={localData.contact || ""}
                  onChange={(e) => handleChange("contact", Number.parseInt(e.target.value))}
                  className="flex-1"
                />
              </div>

              <div className="flex items-center">
                <Label className="w-24">Confinement Period:</Label>
                <span className="mr-2">from</span>
                <Input type="date" className="w-32" />
                <span className="mx-2">to</span>
                <Input type="date" className="w-32" />
              </div>

              <div className="flex items-center">
                <Label className="w-24">Hospital:</Label>
                <Input
                  value={localData.hospital || ""}
                  onChange={(e) => handleChange("hospital", e.target.value)}
                  className="flex-1"
                />
              </div>

              <div className="flex items-center">
                <Label className="w-24">Nature of Illness:</Label>
                <Input
                  value={localData.illness || ""}
                  onChange={(e) => handleChange("illness", e.target.value)}
                  className="flex-1"
                />
              </div>

              <div className="flex items-center">
                <Label className="w-24">Physician:</Label>
                <Input
                  value={localData.physician || ""}
                  onChange={(e) => handleChange("physician", e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center">
                <Label className="w-32">Term AY 20</Label>
                <Input
                  value={localData.term || ""}
                  onChange={(e) => handleChange("term", e.target.value)}
                  className="w-16"
                />
                <span className="mx-2">-20</span>
                <Input
                  value={localData.year || ""}
                  onChange={(e) => handleChange("year", e.target.value)}
                  className="w-16"
                />
              </div>

              <div className="flex items-center">
                <Label className="w-48">Present Teaching Load:</Label>
                <Input
                  value={localData.load || ""}
                  onChange={(e) => handleChange("load", e.target.value)}
                  className="w-16"
                />
                <span className="ml-2">units</span>
              </div>

              <div>
                <Label className="block mb-2">Status:</Label>
                <div className="space-y-2 ml-4">
                  <div className="flex items-center">
                    <Checkbox
                      id="tenured"
                      checked={localData.status === "Tenured"}
                      onCheckedChange={() => handleChange("status", "Tenured")}
                      className="rounded-full"
                    />
                    <Label htmlFor="tenured" className="ml-2">
                      Tenured
                    </Label>
                  </div>

                  <div className="flex items-center">
                    <Checkbox
                      id="tenure-track"
                      checked={localData.status === "Tenure-Track"}
                      onCheckedChange={() => handleChange("status", "Tenure-Track")}
                      className="rounded-full"
                    />
                    <Label htmlFor="tenure-track" className="ml-2">
                      Tenure-Track (Date Hired:
                    </Label>
                    <Input
                      type="date"
                      value={localData.dateHired ? new Date(localData.dateHired).toISOString().split("T")[0] : ""}
                      onChange={(e) => handleChange("dateHired", new Date(e.target.value))}
                      className="w-32 mx-2"
                    />
                    <span>)</span>
                  </div>

                  <div className="flex items-center">
                    <Checkbox
                      id="lecturer"
                      checked={localData.status === "Lecturer before 2001"}
                      onCheckedChange={() => handleChange("status", "Lecturer before 2001")}
                      className="rounded-full"
                    />
                    <Label htmlFor="lecturer" className="ml-2">
                      Lecturer before 2001
                    </Label>
                  </div>

                  <div className="flex items-center">
                    <Checkbox
                      id="extendee"
                      checked={localData.status === "Extendee"}
                      onCheckedChange={() => handleChange("status", "Extendee")}
                      className="rounded-full"
                    />
                    <Label htmlFor="extendee" className="ml-2">
                      Extendee
                    </Label>
                  </div>

                  <div className="flex items-center">
                    <Checkbox
                      id="retiree"
                      checked={localData.status === "Retiree"}
                      onCheckedChange={() => handleChange("status", "Retiree")}
                      className="rounded-full"
                    />
                    <Label htmlFor="retiree" className="ml-2">
                      Retiree (Date Retired:
                    </Label>
                    <Input
                      type="date"
                      value={localData.dateRetired ? new Date(localData.dateRetired).toISOString().split("T")[0] : ""}
                      onChange={(e) => handleChange("dateRetired", new Date(e.target.value))}
                      className="w-32 mx-2"
                    />
                    <span>)</span>
                  </div>
                </div>
              </div>

              <div>
                <Label className="block mb-2">Health Benefits:</Label>
                <div className="space-y-2 ml-4">
                  <div className="flex items-center">
                    <Checkbox
                      id="hmo"
                      checked={localData.benefits === "HMO"}
                      onCheckedChange={() => handleChange("benefits", "HMO")}
                      className="rounded-full"
                    />
                    <Label htmlFor="hmo" className="ml-2">
                      HMO:
                    </Label>
                    <Input
                      value={localData.hmo || ""}
                      onChange={(e) => handleChange("hmo", e.target.value)}
                      className="w-40 ml-2"
                    />
                  </div>

                  <div className="flex items-center">
                    <Checkbox
                      id="pcso"
                      checked={localData.benefits === "PCSO"}
                      onCheckedChange={() => handleChange("benefits", "PCSO")}
                      className="rounded-full"
                    />
                    <Label htmlFor="pcso" className="ml-2">
                      PCSO
                    </Label>
                  </div>

                  <div className="flex items-center">
                    <Checkbox
                      id="senior"
                      checked={localData.benefits === "Senior Citizen"}
                      onCheckedChange={() => handleChange("benefits", "Senior Citizen")}
                      className="rounded-full"
                    />
                    <Label htmlFor="senior" className="ml-2">
                      Senior Citizen
                    </Label>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6">
            <p className="text-sm">
              I hereby certify that all information in this application is true and correct and any misrepresentation of
              facts shall be sufficient cause for denial of this benefit. For any amount in excess of my maximum medical
              & hospitalization benefit, I am personally liable to pay directly to UST Hospital.
            </p>

            <div className="flex justify-end mt-4">
              <div className="w-64">
                <FileUploader
                  onFileSelected={(fileData) => handleFileChange("applicantSignature", fileData)}
                  label="Signature"
                  accept="image/*"
                />
                <div className="border-t border-black mt-2 text-center">
                  <span className="text-xs">Applicant's Signature / Date</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center text-sm border-b border-black pb-1 mb-4">
          Please do not write anything below this line. USTFU use only.
        </div>

        <div className="grid grid-cols-1 gap-4 mb-4">
          <div className="border border-black p-3">
            <h3 className="font-bold">To UST HOSPITAL:</h3>
            <p className="text-sm mb-2">
              This certifies that the above named faculty is entitled to the following benefit on his/her total hospital
              charges, net of PHIC, HMO, SC, AMS, and other applicable deductions, subject to final verification:
            </p>

            <div className="flex items-center mb-1">
              <Checkbox id="fifty" className="rounded-full" />
              <Label htmlFor="fifty" className="ml-2 text-sm">
                50% of net hospital bill
              </Label>
              <div className="flex-1"></div>
              <Checkbox id="hundred" className="rounded-full" />
              <Label htmlFor="hundred" className="ml-2 text-sm">
                100% of net hospital bill
              </Label>
              <span className="ml-4 text-sm">but not to exceed (₱</span>
              <Input className="w-24 mx-1 h-6 text-sm" />
              <span className="text-sm">)</span>
            </div>

            <div className="text-right text-xs italic mb-1">Remaining Benefit</div>

            <p className="text-sm mt-2">
              Any amount in EXCESS of his/her remaining benefit shall be shouldered by the FACULTY in CASH or through
              SALARY DEDUCTION.
            </p>

            <div className="text-right mt-4">
              <div className="inline-block">
                <div className="text-center">for</div>
                <div className="text-center font-bold">EMERITO C. GONZALES</div>
                <div className="text-center text-xs">USTFU President or Authorized Representative (Blue ink)</div>
              </div>
            </div>
          </div>
        </div>

        <div className="border border-black p-3 mb-4">
          <h3 className="font-bold">To UST-USTFU HOSPITALIZATION FUND:</h3>

          <div className="grid grid-cols-3 gap-4">
            <div className="col-span-1">
              <div className="flex items-start mb-2">
                <Checkbox id="pay-hospital" className="mt-1" />
                <Label htmlFor="pay-hospital" className="ml-2 text-sm">
                  Pay UST HOSPITAL the amount of:
                </Label>
              </div>

              <div className="flex items-start mb-2">
                <Checkbox id="refund-faculty" className="mt-1" />
                <Label htmlFor="refund-faculty" className="ml-2 text-sm">
                  Refund the FACULTY the amount of:
                </Label>
              </div>

              <div className="border-2 border-black p-2 mt-4">
                <div className="flex items-start">
                  <Checkbox id="not-covered" className="mt-1" />
                  <Label htmlFor="not-covered" className="ml-2 text-sm">
                    Amount NOT covered by benefits of the FACULTY and will NOT be settled by USTFU. The faculty shall
                    pay this amount directly to UST Hospital.
                  </Label>
                </div>
              </div>
            </div>

            <div className="col-span-1">
              <div className="flex items-center mb-4">
                <Label className="text-sm">₱:</Label>
                <Input className="flex-1 mx-1" />
              </div>

              <div className="flex items-center mb-4">
                <Label className="text-sm">₱:</Label>
                <Input className="flex-1 mx-1" />
              </div>

              <div className="flex items-center mb-4 mt-8">
                <Label className="text-sm">₱:</Label>
                <Input className="flex-1 mx-1" />
              </div>
            </div>

            <div className="col-span-1">
              <div className="mb-2">
                <Checkbox id="pay-doctors" />
                <Label htmlFor="pay-doctors" className="ml-2 text-sm">
                  Pay the following DOCTORS the amount of:
                </Label>
              </div>

              <table className="w-full border-collapse">
                <thead>
                  <tr>
                    <th className="border border-black text-sm p-1">Name</th>
                    <th className="border border-black text-sm p-1">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {[...Array(6)].map((_, i) => (
                    <tr key={i}>
                      <td className="border border-black p-1 h-6"></td>
                      <td className="border border-black p-1 h-6"></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex items-center mt-4">
            <div className="mr-auto">
              <div className="font-bold">USTFU Med-1 Form</div>
            </div>
            <div>
              <Label className="text-sm">By:</Label>
              <div className="w-64 border-b border-black mx-1"></div>
              <div className="text-center text-xs">OIC for Hospitalization and Medical Benefits</div>
            </div>
          </div>
        </div>

        <div className="flex justify-between text-xs">
          <div>Revised: 03/16/2020 ONLINE FORM</div>
        </div>

        <div className="mt-6 border-t pt-4 border-gray-300">
          <h3 className="font-bold mb-2">Required Documents:</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <FileUploader
                onFileSelected={(fileData) => handleFileChange("docRequest", fileData)}
                label="Doctor's Request"
                accept=".pdf,.jpg,.jpeg,.png"
              />
            </div>
            <div>
              <FileUploader
                onFileSelected={(fileData) => handleFileChange("hospitalInvoice", fileData)}
                label="Hospital Invoice"
                accept=".pdf,.jpg,.jpeg,.png"
              />
            </div>
            <div>
              <FileUploader
                onFileSelected={(fileData) => handleFileChange("labInvoice", fileData)}
                label="Laboratory Invoice"
                accept=".pdf,.jpg,.jpeg,.png"
              />
            </div>
            <div>
              <FileUploader
                onFileSelected={(fileData) => handleFileChange("employeeID", fileData)}
                label="Employee ID"
                accept=".jpg,.jpeg,.png"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

