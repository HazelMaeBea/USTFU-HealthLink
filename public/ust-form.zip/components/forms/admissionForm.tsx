"use client"

import { useState, useEffect } from "react"
import type { FormData, AdmissionFormData } from "@/types"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { FileUploader } from "../file-uploader"
import styles from "@/styles/FormGenerator.module.css"

interface AdmissionFormProps {
  formData: Partial<FormData>
  onChange: (data: Partial<FormData>) => void
}

export default function AdmissionForm({ formData, onChange }: AdmissionFormProps) {
  const [localData, setLocalData] = useState<Partial<AdmissionFormData>>({
    ...formData,
    formType: "admission",
  } as Partial<AdmissionFormData>)

  useEffect(() => {
    setLocalData({ ...formData, formType: "admission" } as Partial<AdmissionFormData>)
  }, [formData])

  const handleChange = (field: string, value: any) => {
    const updatedData = { ...localData, [field]: value }
    setLocalData(updatedData)
    onChange(updatedData)
  }

  const handleFileChange = (field: string, fileData: { url: string; filename: string }) => {
    handleChange(field, fileData)
  }

  return (
    <div className={styles.formContainer}>
      <h2 className={styles.formTitle}>Letter of Authority (LOA)</h2>
      <h3 className={styles.formSubtitle}>UST Hospital Admission/Charging (For Faculty Members ONLY)</h3>

      <div className={styles.formGroup}>
        <Label htmlFor="name">NAME:</Label>
        <Input
          id="name"
          value={`${localData.lastname || ""}, ${localData.firstname || ""} ${localData.middlename || ""}`}
          onChange={(e) => {
            const [lastname, firstname, middlename] = e.target.value.split(", ")
            handleChange("lastname", lastname)
            handleChange("firstname", firstname)
            handleChange("middlename", middlename)
          }}
        />
      </div>

      <div className={styles.formGroup}>
        <Label htmlFor="idNo">ID No.:</Label>
        <Input
          id="idNo"
          value={localData.employeeID?.filename || ""}
          onChange={(e) => handleChange("employeeID", { filename: e.target.value, url: "" })}
        />
      </div>

      <div className={styles.formGroup}>
        <Label htmlFor="address">ADDRESS:</Label>
        <Input id="address" value={localData.address || ""} onChange={(e) => handleChange("address", e.target.value)} />
      </div>

      <div className={styles.formGroup}>
        <Label htmlFor="collegeDepartment">COLLEGE/DEPARTMENT:</Label>
        <Input
          id="collegeDepartment"
          value={localData.college || ""}
          onChange={(e) => handleChange("college", e.target.value)}
        />
      </div>

      <div className={styles.formGroup}>
        <Label htmlFor="teachingLoad">Present Teaching Load:</Label>
        <Input id="teachingLoad" value={localData.load || ""} onChange={(e) => handleChange("load", e.target.value)} />
        <span>units</span>
      </div>

      <div className={styles.formGroup}>
        <Label>Status:</Label>
        <div className={styles.checkboxGroup}>
          <Checkbox
            id="tenured"
            checked={localData.status === "Tenured"}
            onCheckedChange={() => handleChange("status", "Tenured")}
          />
          <Label htmlFor="tenured">Tenured</Label>

          <Checkbox
            id="lecturer"
            checked={localData.status === "Lecturer before 2001"}
            onCheckedChange={() => handleChange("status", "Lecturer before 2001")}
          />
          <Label htmlFor="lecturer">Lecturer before 2001</Label>

          <Checkbox
            id="extendee"
            checked={localData.status === "Extendee"}
            onCheckedChange={() => handleChange("status", "Extendee")}
          />
          <Label htmlFor="extendee">Extendee</Label>

          <div className={styles.inlineCheckbox}>
            <Checkbox
              id="probationary"
              checked={localData.status === "Probationary"}
              onCheckedChange={() => handleChange("status", "Probationary")}
            />
            <Label htmlFor="probationary">Probationary (Date Hired:</Label>
            <Input
              type="date"
              value={localData.dateHired ? new Date(localData.dateHired).toISOString().split("T")[0] : ""}
              onChange={(e) => handleChange("dateHired", new Date(e.target.value))}
            />
            <span>)</span>
          </div>

          <div className={styles.inlineCheckbox}>
            <Checkbox
              id="retiree"
              checked={localData.status === "Retiree"}
              onCheckedChange={() => handleChange("status", "Retiree")}
            />
            <Label htmlFor="retiree">Retiree (Date Retired:</Label>
            <Input
              type="date"
              value={localData.dateRetired ? new Date(localData.dateRetired).toISOString().split("T")[0] : ""}
              onChange={(e) => handleChange("dateRetired", new Date(e.target.value))}
            />
            <span>)</span>
          </div>

          <div className={styles.inlineCheckbox}>
            <Checkbox
              id="others"
              checked={localData.status === "Others"}
              onCheckedChange={() => handleChange("status", "Others")}
            />
            <Label htmlFor="others">Others:</Label>
            <Input value={localData.otherStatus || ""} onChange={(e) => handleChange("otherStatus", e.target.value)} />
          </div>
        </div>
      </div>

      <div className={styles.formGroup}>
        <h4>TO: UNIVERSITY OF SANTO TOMAS HOSPITAL</h4>
        <p>
          This is certify that ______________________ is University of Santo Tomas academic personnel and is allowed to
          charge his/her hospital bill up to the limit indicated below by the Accounting Department subject to the rules
          and conditions of the University of Santo Tomas Hospital and the Joint UST-USTFU Hospitalization and Medical
          Benefits Committee.
        </p>
      </div>

      <div className={styles.formGroup}>
        <Label>To be filled up by official USTFU staff:</Label>
        <div className={styles.radioGroup}>
          <RadioGroup
            value={localData.benefitPercentage || ""}
            onValueChange={(value) => handleChange("benefitPercentage", value)}
          >
            <div className={styles.radioItem}>
              <RadioGroupItem value="50" id="fifty-percent" />
              <Label htmlFor="fifty-percent">50% of net hospital bill</Label>
            </div>
            <div className={styles.radioItem}>
              <RadioGroupItem value="100" id="hundred-percent" />
              <Label htmlFor="hundred-percent">100% of net hospital bill</Label>
            </div>
          </RadioGroup>
          <div className={styles.inlineInput}>
            <span>but not to exceed (₱</span>
            <Input
              value={localData.benefitLimit || ""}
              onChange={(e) => handleChange("benefitLimit", e.target.value)}
            />
            <span>)</span>
          </div>
        </div>
      </div>

      <div className={styles.signatureSection}>
        <div className={styles.signatureLine}>
          <Label>Signature over Printed Name/USTFU Officer/Staff</Label>
          <Input />
        </div>
        <div className={styles.signatureLine}>
          <Label>Date</Label>
          <Input type="date" />
        </div>
      </div>

      <div className={styles.signatureSection}>
        <div className={styles.signatureLine}>
          <Label>Signature over Printed Name/OVRAA</Label>
          <Input />
        </div>
        <div className={styles.signatureLine}>
          <Label>Date</Label>
          <Input type="date" />
        </div>
      </div>

      <div className={styles.footer}>
        <p>FOR ADMISSION PURPOSES ONLY; GET IN-PATIENT FORM PRIOR TO DISCHARGE</p>
      </div>

      <div className={styles.uploadSection}>
        <h3>Required Documents:</h3>
        <div className={styles.uploadGrid}>
          <FileUploader
            onFileSelected={(fileData) => handleFileChange("docRequest", fileData)}
            label="Doctor's Request"
            accept=".pdf,.jpg,.jpeg,.png"
          />
          <FileUploader
            onFileSelected={(fileData) => handleFileChange("hospitalInvoice", fileData)}
            label="Hospital Invoice"
            accept=".pdf,.jpg,.jpeg,.png"
          />
          <FileUploader
            onFileSelected={(fileData) => handleFileChange("labInvoice", fileData)}
            label="Laboratory Invoice"
            accept=".pdf,.jpg,.jpeg,.png"
          />
          <FileUploader
            onFileSelected={(fileData) => handleFileChange("employeeID", fileData)}
            label="Employee ID"
            accept=".jpg,.jpeg,.png"
          />
        </div>
      </div>
    </div>
  )
}

