"use client"

import jsPDF from "jspdf"
import html2canvas from "html2canvas"

export const generatePDF = async (element: HTMLElement, filename: string) => {
  try {
    // Show loading state
    const loadingDiv = document.createElement("div")
    loadingDiv.className = "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
    loadingDiv.innerHTML = '<div class="bg-white p-4 rounded-md">Generating PDF...</div>'
    document.body.appendChild(loadingDiv)

    // Create canvas from the form element
    const canvas = await html2canvas(element, {
      scale: 2, // Higher scale for better quality
      useCORS: true, // Enable CORS for images
      logging: false,
      allowTaint: true,
      backgroundColor: "#ffffff",
    })

    // Calculate dimensions to maintain aspect ratio
    const imgData = canvas.toDataURL("image/png")
    const pdf = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4",
    })

    const imgWidth = 210 // A4 width in mm
    const pageHeight = 297 // A4 height in mm
    const imgHeight = (canvas.height * imgWidth) / canvas.width

    let heightLeft = imgHeight
    let position = 0

    // Add first page
    pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight)
    heightLeft -= pageHeight

    // Add additional pages if needed
    while (heightLeft > 0) {
      position = heightLeft - imgHeight
      pdf.addPage()
      pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight)
      heightLeft -= pageHeight
    }

    // Save the PDF
    pdf.save(`${filename}.pdf`)

    // Remove loading state
    document.body.removeChild(loadingDiv)
  } catch (error) {
    console.error("Error generating PDF:", error)
    alert("Error generating PDF. Please try again.")
  }
}

